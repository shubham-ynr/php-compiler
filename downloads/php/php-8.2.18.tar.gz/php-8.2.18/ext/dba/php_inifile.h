#ifndef PHP_INIFILE_H
#define PHP_INIFILE_H

#ifdef DBA_INIFILE

#include "php_dba.h"

DBA_FUNCS(inifile);

#endif

#endif
