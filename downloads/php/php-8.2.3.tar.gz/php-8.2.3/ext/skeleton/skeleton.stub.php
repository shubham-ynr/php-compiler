<?php

/**
 * @generate-class-entries
 * @undocumentable
 */

function test1(): void {}

function test2(string $str = ""): string {}
