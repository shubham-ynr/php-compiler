<?php

/**
 * @generate-class-entries static
 * @undocumentable
 */

namespace ZendTest\Iterators;

final class TraversableTest implements \IteratorAggregate
{
    public function __construct() {}
    public function getIterator(): \Iterator {}
}
