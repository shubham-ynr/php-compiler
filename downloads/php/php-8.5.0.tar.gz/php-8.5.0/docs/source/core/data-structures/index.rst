#################
 Data structures
#################

.. toctree::
   :hidden:

   zval
   reference-counting
   zend_string
   zend_constant

This section provides an overview of the core data structures used in php-src.
